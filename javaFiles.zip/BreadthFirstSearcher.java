// Name: Brennan Mowry
// Class: cs540

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Breadth-First Search (BFS)
 * 
 */
public class BreadthFirstSearcher extends Searcher {

	/**
	 * Calls the parent class constructor.
	 * 
	 * @see Searcher
	 * @param maze initial maze.
	 */
	public BreadthFirstSearcher(Maze maze) {
		super(maze);
	}

	/**
	 * Main breadth first search algorithm.
	 * 
	 * @return true if the search finds a solution, false otherwise.
	 */
	public boolean search() {
		// explored list is a 2D Boolean array that indicates if a state associated with a given position in the maze has already been explored.
		boolean[][] explored = new boolean[maze.getNoOfRows()][maze.getNoOfCols()];

		// Queue implementing the Frontier list
		LinkedList<State> queue = new LinkedList<State>();
		
		// add the starting node to the queue
		State playerSquareState = new State(maze.getPlayerSquare(), null, 0, 0);
		queue.add(playerSquareState);
		
		State current;
		ArrayList<State> successors;
		
		while (!queue.isEmpty()) {
			current = queue.pop();
			if (!explored[current.getX()][current.getY()]) {
				noOfNodesExpanded += 1;
				// update the explored array
				explored[current.getX()][current.getY()] = true;
			}
			// get the cost of the current node
			cost = current.getDepth();
			// update the maxDepthSearched if the current node is deeper
			if (current.getDepth() > maxDepthSearched) {
				maxDepthSearched = current.getDepth();
			}
			
			if (current.isGoal(maze)) {
				// update the maze
				current = current.getParent();
				while(current.getX() != playerSquareState.getX() || current.getY() != playerSquareState.getY()) {
					maze.setOneSquare(current.getSquare(), '.');
					current = current.getParent();
				}
				return true;
			}
			// used to check if the potential successor is already in the frontier, so that the maxSizeOfFrontier count is correct
			boolean toggle = false;
			// update the frontier
			successors = current.getSuccessors(explored, maze);
			for (int i = 0; i < successors.size(); i++) {
				for (int j = 0; j < queue.size(); j++) {
					if (successors.get(i).getX() == queue.get(j).getX() && successors.get(i).getY() == queue.get(j).getY()) {
						toggle = true;
					}
				}
				if (!toggle) {
					queue.add(successors.get(i));
				}
				toggle = false;
			}
			// update the max size of the frontier
			if (queue.size() > maxSizeOfFrontier) {
				maxSizeOfFrontier = queue.size();
			}

			// use queue.pop() to pop the queue.
			// use queue.add(...) to add elements to queue
		}

		return false;
	}
}
