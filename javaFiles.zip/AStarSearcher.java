// Name: Brennan Mowry
// Class: cs540

import java.util.ArrayList;
import java.util.PriorityQueue;

/**
 * A* algorithm search
 * 
 */
public class AStarSearcher extends Searcher {

	/**
	 * Calls the parent class constructor.
	 * 
	 * @see Searcher
	 * @param maze initial maze.
	 */
	public AStarSearcher(Maze maze) {
		super(maze);
	}

	/**
	 * Main a-star search algorithm.
	 * 
	 * @return true if the search finds a solution, false otherwise.
	 */
	public boolean search() {

		// explored list is a Boolean array that indicates if a state associated with a given position in the maze has already been explored. 
		boolean[][] explored = new boolean[maze.getNoOfRows()][maze.getNoOfCols()];

		PriorityQueue<StateFValuePair> frontier = new PriorityQueue<StateFValuePair>();
		
		// create the initial StateFValuePair
		State playerSquareState = new State(maze.getPlayerSquare(), null, 0, 0);
		StateFValuePair start = new StateFValuePair(playerSquareState, 0);
		
		// add it to the frontier
		frontier.add(start);
		
		StateFValuePair current;
		
		State currentForModifyingMatrix;
		
		ArrayList<State> successors;
		
		ArrayList<StateFValuePair> frontierStates =  new ArrayList<StateFValuePair>();
		
		while (!frontier.isEmpty()) {
			
			current = frontier.poll();
			
			if (!explored[current.getState().getX()][current.getState().getY()]) {
				noOfNodesExpanded += 1;
				// update the explored array
				explored[current.getState().getX()][current.getState().getY()] = true;
			}
			
			
			// get the cost of the current node
			cost = current.getState().getDepth();
			// update the maxDepthSearched if the current node is deeper
			if (cost > maxDepthSearched) {
				maxDepthSearched = cost;
			}
			if (current.getState().isGoal(maze)) {
				// modify the matrix for printing
				currentForModifyingMatrix = current.getState().getParent();
				while(currentForModifyingMatrix.getX() != playerSquareState.getX() || currentForModifyingMatrix.getY() != playerSquareState.getY()) {
					maze.setOneSquare(currentForModifyingMatrix.getSquare(), '.');
					currentForModifyingMatrix = currentForModifyingMatrix.getParent();
				}
				return true;
			}
			
			// update the frontier
			// get the potential successors
			successors = current.getState().getSuccessors(explored, maze);
			// get the elements from the frontier for comparison
			while (!frontier.isEmpty()) {
				frontierStates.add(frontier.poll());
			}

			if (frontierStates.size() == 0) {
				for (int i = 0; i < successors.size(); i++) {
					frontier.add(new StateFValuePair(successors.get(i), successors.get(i).getGValue() + h(successors.get(i))));
				}
			}
			boolean toggle = false;
			// for each potential successor, test if it is in the frontier already
			for (int i = 0; i < successors.size(); i++) {
				for (int j = 0; j < frontierStates.size(); j++) {
					if (successors.get(i).getX() == frontierStates.get(j)
							.getState().getX()
							&& successors.get(i).getY() == frontierStates
									.get(j).getState().getY()) {
						toggle = true;
						if ((successors.get(i).getGValue() + h(successors.get(i)) >= frontierStates.get(j).getFValue())) {
						}
						if ((successors.get(i).getGValue() + h(successors.get(i)) < frontierStates.get(j).getFValue())) {
							frontierStates.remove(j);
							frontierStates.add(new StateFValuePair(successors.get(i), successors.get(i).getGValue() + h(successors.get(i))));
						}
					}
				}
				if (!toggle) {
					frontierStates.add(new StateFValuePair(successors.get(i), successors.get(i).getGValue() + h(successors.get(i))));
				}
				toggle = false;
			}
			// put the states back into the priority queue
			for (int i = frontierStates.size() - 1; i >= 0; i--) {
				frontier.add(frontierStates.remove(i));
			}

			// update the max size of the frontier
			if (frontier.size() > maxSizeOfFrontier) {
				maxSizeOfFrontier = frontier.size();
			}
		}

		return false;
	}
	
	private double h(State current) {
		
		return Math.sqrt(Math.pow(current.getX() - maze.getGoalSquare().X , 2)+ Math.pow(current.getY() - maze.getGoalSquare().Y, 2));
	}

}
